@ECHO OFF
:: CIP-B101 Lab 1C - Windows system information collection
TITLE CIP-B101 System Info Collection
ECHO Please wait... Checking system information.
ECHO ========================== > ..\outputs\sys_info_report.txt
ECHO WINDOWS INFO >> ..\outputs\sys_info_report.txt
ECHO ========================== >> ..\outputs\sys_info_report.txt
systeminfo | find "OS Name" >> ..\outputs\sys_info_report.txt
systeminfo | find "OS Version" >> ..\outputs\sys_info_report.txt
systeminfo | find "System Type" >> ..\outputs\sys_info_report.txt
ECHO. >> ..\outputs\sys_info_report.txt
ECHO ========================== >> ..\outputs\sys_info_report.txt
ECHO HARDWARE INFO >> ..\outputs\sys_info_report.txt
ECHO ========================== >> ..\outputs\sys_info_report.txt
systeminfo | find "Total Physical Memory" >> ..\outputs\sys_info_report.txt
wmic cpu get name >> ..\outputs\sys_info_report.txt
wmic diskdrive get name,model,size >> ..\outputs\sys_info_report.txt
ECHO. >> ..\outputs\sys_info_report.txt
ECHO ========================== >> ..\outputs\sys_info_report.txt
ECHO NETWORK INFO >> ..\outputs\sys_info_report.txt
ECHO ========================== >> ..\outputs\sys_info_report.txt
ipconfig | findstr IPv4 >> ..\outputs\sys_info_report.txt
wmic nic get macaddress,description >> ..\outputs\sys_info_report.txt
START https://support.microsoft.com/en-us/windows/windows-10-system-requirements-6d4e9a79-66bf-7950-467c-795cf0386715
ECHO Collection complete. See outputs\sys_info_report.txt
PAUSE
